import React from "react";
import createUser from "./api/createUser";
import deal from "./api/deal";
import users from "./api/users";

const Home = () => {
  return <div>Home</div>;
};

export default Home;
